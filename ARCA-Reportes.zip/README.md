# Arca Reportes

App Streamlit para analizar comprobantes AFIP.

### Ejecución local
```bash
pip install -r requirements.txt
streamlit run app_streamlit_auth.py
```

### Despliegue en Streamlit Cloud
1. Subí el repo a GitHub.
2. Entrá a [https://share.streamlit.io](https://share.streamlit.io)
3. Conectá tu repo `ARCA-Reportes`.
4. ¡Listo!
